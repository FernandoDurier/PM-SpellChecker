package modelo;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import leitor.LeitorArquivoZip;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class BKTreeTest {

    public BKTreeTest() {
    }

    /**
     * Test do método corrigir, da classe BKTree.
     */
    @Test
    public void testCorrigir() throws IOException {
        System.out.println("Corrigir");
        KeyboardLayout layout = new KeyboardLayout();

        layout.setTipo("Neutro");
        layout.setLine1("");
        layout.setLine2("");
        layout.setLine3("");
        layout.setOffset2(0);
        layout.setOffset3(0);

        String metodo = "DamereauLevensthein";
        Node raiz = new Node("A", metodo, layout);
        BKTree instance = new BKTree(raiz, metodo, layout);

        File arquivorelativo = new File("../SpellChecker/src/main/java/arquivos/dictionary_pt-br.zip");
        String caminhoRelativo = arquivorelativo.getCanonicalPath();
        BufferedReader leitorBuffer = LeitorArquivoZip.read(caminhoRelativo);
        String linha = leitorBuffer.readLine();
        while (leitorBuffer.ready()) {
            linha = leitorBuffer.readLine();
            instance.Add(linha);
        }

        String result = instance.corrigir("caza", raiz, 100);
        assertEquals("cada", result);

    }

}
