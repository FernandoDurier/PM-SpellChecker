package controlador;

import modelo.KeyboardLayout;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class CalculadorDistanciaLevenstheinTest {

    public CalculadorDistanciaLevenstheinTest() {
    }

    /**
     * Teste do metodo distanciaLevensthein, da classe
     * CalculadorDistanciaLevensthein.
     */
    @Test
    public void testDistanciaLevensthein() {
        KeyboardLayout kl = new KeyboardLayout();
        kl.setTipo("Neutro");
        kl.setLine1("");
        kl.setLine2("");
        kl.setLine3("");
        kl.setOffset2(0);
        kl.setOffset3(0);
        System.out.println("distanciaLevensthein");
        String palavraErrada = "cadq";
        String palavraCorreta = "cade";
        CalculadorDistanciaLevensthein instance = new CalculadorDistanciaLevensthein(palavraErrada, palavraCorreta, kl);
        double expResult = 1.0;
        double result = instance.distancia(palavraErrada, palavraCorreta);
        assertEquals(expResult, result, 1.0);
        assertEquals(0.0, instance.distancia("abadia", "abadia"), 0.0);
        assertEquals(1.0, instance.distancia("abadik", "abadia"), 1.0);
        assertEquals(2.0, instance.distancia("abadxk", "abadia"), 2.0);
        assertEquals(3.0, instance.distancia("abacik", "abadia"), 3.0);
        assertEquals(4.0, instance.distancia("abedxk", "abadia"), 4.0);
        assertEquals(6.0, instance.distancia("", "abadia"), 6.0);
    }

}
