package controlador;

import modelo.KeyboardLayout;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class CalculadorDistanciaDamereauLevenstheinTest {

    public CalculadorDistanciaDamereauLevenstheinTest() {
    }

    /**
     * Teste do método da distancia, daclasse
     * CalculadorDistanciaDamereauLevensthein.
     */
    @Test
    public void testDistancia() {
        KeyboardLayout kl = new KeyboardLayout();
        kl.setTipo("Neutro");
        kl.setLine1("");
        kl.setLine2("");
        kl.setLine3("");
        kl.setOffset2(0);
        kl.setOffset3(0);
        System.out.println("distancia");
        String palavraErrada = "";
        String palavraCorreta = "";
        CalculadorDistanciaDamereauLevensthein instance = new CalculadorDistanciaDamereauLevensthein(palavraErrada, palavraCorreta, kl);

        assertEquals(0.0, instance.distancia("abadia", "abadia"), 0.0);
        assertEquals(0.0, instance.distancia("abadia", "abadik"), 1.0);
        assertEquals(0.0, instance.distancia("abadia", "abadjk"), 2.0);
        assertEquals(0.0, instance.distancia("abadia", "abachk"), 3.0);
        assertEquals(0.0, instance.distancia("abadia", "abyuol"), 4.0);
        assertEquals(0.0, instance.distancia("abadia", "ahnmok"), 5.0);
        assertEquals(0.0, instance.distancia("abadia", ""), 6.0);

        KeyboardLayout kl2 = new KeyboardLayout();
        kl2.setTipo("QWERTY");
        kl2.setLine1("QWERTYUIOP");
        kl2.setLine2("ASDFGHJKL");
        kl2.setLine3("ZXCVBNM");
        kl2.setOffset2(0.5);
        kl2.setOffset3(0.5);
        System.out.println("distancia");
        String palavraErrada2 = "";
        String palavraCorreta2 = "";
        CalculadorDistanciaDamereauLevensthein instance2 = new CalculadorDistanciaDamereauLevensthein(palavraErrada2, palavraCorreta2, kl2);

        assertEquals(0.0, instance2.distancia("cada", "cada"), 0.0);
        assertEquals(1.0, instance2.distancia("cada", "caza"), 1.0);
        assertEquals(2.0, instance2.distancia("cada", "cazx"), 2.0);
        assertEquals(3.0, instance2.distancia("cada", "cvxz"), 3.0);
        assertEquals(4.0, instance2.distancia("cada", ""), 4.0);
        assertEquals(1.0, instance2.distancia("cada", "caad"), 1.0);

    }

}
