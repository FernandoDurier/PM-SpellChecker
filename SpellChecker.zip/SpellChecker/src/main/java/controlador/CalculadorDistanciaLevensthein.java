package controlador;

import lombok.Data;
import modelo.KeyboardLayout;

/**
 * Realiza o cálculo de distância entre duas palavras utilizando o algoritmo de
 * Levensthein, que possui três operações: inserção, substituição e deleção.
 */
@Data
public class CalculadorDistanciaLevensthein {

    private String palavraErrada;
    private String palavraCorreta;
    private KeyboardLayout layout;
    private double[][] distanciaTeclas;

    /**
     * Construtor da classe CalculadorDistanciaLevensthein que possui três
     * parâmetros: palavra errada, palavra correta (no dicionário) e modelo de
     * teclado
     *
     * @param palavraErrada
     * @param palavraCorreta
     * @param layout
     */
    public CalculadorDistanciaLevensthein(String palavraErrada, String palavraCorreta, KeyboardLayout layout) {
        this.palavraErrada = palavraErrada;
        this.palavraCorreta = palavraCorreta;
        this.layout = layout;
        this.distanciaTeclas = layout.prepararDistancias();
    }

    /**
     * Algoritmo que calcula a distância de Levensthein entre duas palavras: uma
     * errada e outra correta. Informa o número mínimo de operações que devem
     * ser realizadas para transformar a primeira palavra na segunda
     *
     * @param palavraErrada
     * @param palavraCorreta
     * @return
     */
    public double distancia(String palavraErrada, String palavraCorreta) {

        // Transformar palavras em caixa baixa
        palavraErrada = palavraErrada.toLowerCase();
        palavraCorreta = palavraCorreta.toLowerCase();

        int tamanhoPalavraErrada = palavraCorreta.length();

        // Cria vetor para armazenar custos de operações entre caracteres
        double[] custos = new double[tamanhoPalavraErrada + 1];

        // Preenche cada posição do vetor com valor de custo igual à posicão de cada caracter no vetor
        // i == 0
        for (int j = 0; j < custos.length; j++) {
            custos[j] = j;
        }

        for (int i = 1; i <= palavraErrada.length(); i++) {
            // j == 0; nw = lev(i - 1, j)
            custos[0] = i;
            double nw = i - 1;
            for (int j = 1; j <= tamanhoPalavraErrada; j++) {
                int posicaoPalavraErrada = -1;
                int posicaoPalavraCorreta = -1;
                boolean espacoVazio = false;
                int x = 0;
                for (char caracter = 'a'; caracter <= 'z'; caracter++) {
                    if (palavraErrada.charAt(i - 1) == caracter) {
                        posicaoPalavraErrada = x;
                    }
                    if (palavraErrada.charAt(i - 1) == '-' || palavraErrada.charAt(i - 1) == '\'' || palavraErrada.charAt(i - 1) == '.') {
                        espacoVazio = true;
                    }
                    x++;
                }

                int y = 0;
                for (char caracter = 'a'; caracter <= 'z'; caracter++) {
                    if (palavraCorreta.charAt(j - 1) == caracter) {
                        posicaoPalavraCorreta = y;
                    }
                    if (palavraCorreta.charAt(j - 1) == '-' || palavraCorreta.charAt(j - 1) == '\'' || palavraCorreta.charAt(j - 1) == '.') {
                        espacoVazio = true;
                    }
                    y++;
                }

                double cj;

                if (espacoVazio == false) {
                    cj = Math.min(1 + Math.min(custos[j], custos[j - 1]),
                            palavraErrada.charAt(i - 1) == palavraCorreta.charAt(j - 1) ? nw : nw + 1 * distanciaTeclas[posicaoPalavraErrada][posicaoPalavraCorreta]);
                } else {
                    cj = Math.min(1 + Math.min(custos[j], custos[j - 1]),
                            palavraErrada.charAt(i - 1) == palavraCorreta.charAt(j - 1) ? nw : nw + 1);
                }

                nw = custos[j];
                custos[j] = cj;
            }
        }
        return custos[tamanhoPalavraErrada]; // retorna o valor da distância mínima para transformar a palavra errada na correta
    }
}
