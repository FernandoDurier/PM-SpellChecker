package controlador;

import lombok.Data;
import modelo.KeyboardLayout;

/**
 * Realiza o cálculo de distância entre duas palavras utilizando o algoritmo de
 * Damereau Levensthein, que inclui a operação de transposição.
 */
public @Data
class CalculadorDistanciaDamereauLevensthein {

    private String palavraErrada;
    private String palavraCorreta;
    private KeyboardLayout layout;
    private double[][] distanciaTeclas;

    public CalculadorDistanciaDamereauLevensthein(String palavraErrada, String palavraCorreta, KeyboardLayout modeloTeclado) {
        this.palavraErrada = palavraErrada;
        this.palavraCorreta = palavraCorreta;
        this.layout = modeloTeclado;
        this.distanciaTeclas = modeloTeclado.prepararDistancias();
    }

    public double distancia(String palavraErrada, String palavraCorreta) {

        // Obter tamanho de cada uma das duas strings
        int tamanhoPalavraErrada = palavraErrada.length(),
                tamanhoPalavraCorreta = palavraCorreta.length();

        // Criar matriz para armazenar as duas palavras
        double[][] distancia = new double[tamanhoPalavraErrada + 1][tamanhoPalavraCorreta + 1];
        double custoDistancia = 0;

        for (int i = 0; i <= tamanhoPalavraErrada; i++) {
            distancia[i][0] = i;
        }
        for (int j = 0; j <= tamanhoPalavraCorreta; j++) {
            distancia[0][j] = j;
        }

        // Realiza a verificação de distância de cada caracter
        for (int k = 1; k <= tamanhoPalavraErrada; k++) {
            for (int l = 1; l <= tamanhoPalavraCorreta; l++) {
                if (palavraErrada.charAt(k - 1) == palavraCorreta.charAt(l - 1)) {
                    custoDistancia = 0;
                } else {
                    String caracterPalavraErrada = "";  // Transformar as letras em caixa baixa
                    caracterPalavraErrada += palavraErrada.charAt(k - 1);
                    String caracterPalavraCorreta = "";
                    caracterPalavraCorreta += palavraCorreta.charAt(l - 1);
                    caracterPalavraErrada = caracterPalavraErrada.toLowerCase();
                    caracterPalavraCorreta = caracterPalavraCorreta.toLowerCase();
                    char x = caracterPalavraErrada.charAt(0);
                    char y = caracterPalavraCorreta.charAt(0);
                    //saber onde essas letras estão na matriz alfabética

                    int indiceCaracterPalavraErrada = -1;
                    int indiceCaracterPalavraCorreta = -1;
                    boolean blank = false;
                    int i = 0;
                    for (char caracter = 'a'; caracter <= 'z'; caracter++) {
                        if (x == caracter) {
                            indiceCaracterPalavraErrada = i;
                        }
                        if (x == '-' || x == '\'' || x == '.') {
                            blank = true;
                        }
                        i++;
                    }

                    int j = 0;
                    for (char caracter = 'a'; caracter <= 'z'; caracter++) {
                        if (y == caracter) {
                            indiceCaracterPalavraCorreta = j;
                        }
                        if (y == '-' || y == '\'' || y == '.') {
                            blank = true;
                        }
                        j++;
                    }
                    if (blank == false) {
                        custoDistancia = 1 * distanciaTeclas[indiceCaracterPalavraErrada][indiceCaracterPalavraCorreta];//multiplicar pelo retorno do calculo da distancia do teclado
                    } else {
                        custoDistancia = 1;
                    }
                }
                distancia[k][l] = Math.min(distancia[k - 1][l] + 1,
                        Math.min(distancia[k][l - 1] + 1, distancia[k - 1][l - 1] + custoDistancia));
                if (k > 1 && l > 1
                        && palavraErrada.charAt(k - 1) == palavraCorreta.charAt(l - 2)
                        && palavraErrada.charAt(k - 2) == palavraCorreta.charAt(l - 1)) {
                    distancia[k][l] = Math.min(distancia[k][l], distancia[k - 2][l - 2] + custoDistancia);
                }
            }
        }
        return distancia[tamanhoPalavraErrada][tamanhoPalavraCorreta];
    }
}
