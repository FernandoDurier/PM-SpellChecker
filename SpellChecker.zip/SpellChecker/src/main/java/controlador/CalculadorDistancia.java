package controlador;

import lombok.Data;
import modelo.KeyboardLayout;

public @Data
class CalculadorDistancia {

    /**
     * Calcula a distância entre duas palavras a partir de um algoritmo específico
     * e de um layout de teclado
     */
    public double calcula(String palavraErrada, String palavraCorreta, String metodo, KeyboardLayout modeloTeclado) {
        CalculadorDistanciaDamereauLevensthein calculadorDamereauLevensthein = new CalculadorDistanciaDamereauLevensthein(palavraErrada, palavraCorreta, modeloTeclado);
        CalculadorDistanciaLevensthein calculadorLevensthein = new CalculadorDistanciaLevensthein(palavraErrada, palavraCorreta, modeloTeclado);

        if (metodo.equals("d")) { // Se cálculo da distância com Damereau Levensthein
            return calculadorDamereauLevensthein.distancia(palavraErrada, palavraCorreta);
        } else { // Se cálculo da distância com Levensthein
            return calculadorLevensthein.distancia(palavraErrada, palavraCorreta);
        }
    }

}
