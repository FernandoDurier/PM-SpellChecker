/**
 * @author Fernando Durier e Júlio Campos
 * Disciplina: Programação Modular
 * Professor: Márcio Barros
 */
package visao;

import leitor.LeitorTeclado;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import modelo.KeyboardLayout;
import controlador.CalculadorDistancia;
import java.io.BufferedReader;
import java.util.Scanner;
import leitor.LeitorArquivoZip;
import modelo.BKTree;
import modelo.Node;

/**
 * Classe principal do projeto, estruturado no padrão MVC. Constrói uma BKTree
 * para realizar a verificação ortógráfica de uma palavra digitada por um
 * usuário a partir de um dicionário carregado pelo programa.
 */
public class Main {

    /**
     * Verificador ortográfico que realiza o cálculo da distância entre duas
     * palavras usando o algoritmo de Damereau ou o algoritmo Damereau
     * Levensthein com base em modelo de teclado escolhido pelo usuário.
     */
    public static void main(String[] args) throws IOException {
        CalculadorDistancia calculadorDistancia = new CalculadorDistancia();
        LeitorTeclado modeloTeclado = new LeitorTeclado();
        ArrayList<KeyboardLayout> listaTeclados = modeloTeclado.getLayoutTecladoDoXML();

        File arquivorelativo = new File("../SpellChecker/src/main/java/arquivos/dictionary_pt-br.zip");
        String caminhoRelativo = arquivorelativo.getCanonicalPath();
        BufferedReader leitorBuffer = LeitorArquivoZip.read(caminhoRelativo);
        //Ou o metodo eh DamereauLevensthein ou eh Levensthein

        String algoritmo;
        Scanner input = new Scanner(System.in);

        System.out.println("Selecione um algoritmo: (d) Damereau ou (l) Levensthein");
        algoritmo = input.nextLine();

        if (algoritmo == "d") {
            System.out.println("Distância de Damereau Levensthein selecionada.");
        } else {
            System.out.println("Distância de Levensthein selecionada.");
        }

        String teclado;
        System.out.println("Digite um modelo de teclado: 1-QWERTY 2-QWERTZ 3-AZERTY 4-DVORAK 5-COLEMAN 6-WORKMAN 7-NEUTRO");
        teclado = input.nextLine();
        KeyboardLayout tecladoSelecionado = null;

        for (int i = 0; i < listaTeclados.size(); i++) {
            if (listaTeclados.get(i).getTipo().equals(teclado)) {
                tecladoSelecionado = listaTeclados.get(i);
            }
            if (i == listaTeclados.size() - 1 && tecladoSelecionado == null) {
                System.out.println("Erro! Teclado selecionado não existe. O teclado neutro será considerado na verificação ortográfica.");
                tecladoSelecionado = listaTeclados.get(6); // Teclado neutro
            }
        }
        System.out.println("Construindo a BK Tree...");

        String linha = leitorBuffer.readLine();
        BKTree arvoreBK = new BKTree(new Node(linha, algoritmo, tecladoSelecionado), algoritmo, tecladoSelecionado);
        while (leitorBuffer.ready()) {
            linha = leitorBuffer.readLine();
            arvoreBK.Add(linha);
        }

        String entrada;
        System.out.println("Digite uma palavra: ");
        entrada = input.nextLine();

        int tolerancia;
        System.out.println("Digite um valor de tolerância (em múltiplos de 100).");
        tolerancia = input.nextInt();

        System.out.println("Você digitou: " + entrada + ". Você quis dizer " + arvoreBK.corrigir(entrada, arvoreBK.getRoot(), tolerancia) + "?");

    }
}
