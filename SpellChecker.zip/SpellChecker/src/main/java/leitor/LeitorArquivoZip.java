package leitor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Leitor de arquivos em formato de extensão .zip que utiliza um leitor de
 * armazenamento em buffer
 */
public class LeitorArquivoZip {

    public static BufferedReader read(String path) throws IOException {
        ZipFile arquivoZip = new ZipFile(path);
        Enumeration<? extends ZipEntry> entries = arquivoZip.entries();
        String caminhoArquivo = null;
        InputStream entrada = null;
        while (entries.hasMoreElements()) {
            ZipEntry entradaZip = entries.nextElement();
            if (entradaZip.toString().equals("dictionary pt-br.dic")) {
                entrada = arquivoZip.getInputStream(entradaZip);
                break;
            }
        }
        if (entrada != null) {
            BufferedReader leitorBuffer = new BufferedReader(new InputStreamReader(entrada, "UTF-8"));
            return leitorBuffer;
        }
        return null;
    }
}
