package leitor;

import java.io.File;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import modelo.KeyboardLayout;

/**
 * Realiza a leitura de seis modelos de teclado distintos em arquivo de extensão
 * .xml e retorna uma lista de modelos desses teclados.
 */
public class LeitorTeclado {

    private ArrayList<KeyboardLayout> listaDeTeclados = new ArrayList<KeyboardLayout>();

    public ArrayList<KeyboardLayout> getLayoutTecladoDoXML() {
        try {
            File arquivoXML = new File("../SpellChecker/src/main/java/arquivos/KeyboardLayouts.xml");
            DocumentBuilderFactory fabricaConstrutorDocumentos = DocumentBuilderFactory.newInstance();
            DocumentBuilder construtorDocumento = fabricaConstrutorDocumentos.newDocumentBuilder();
            Document documento = construtorDocumento.parse(arquivoXML);
            documento.getDocumentElement().normalize();

            NodeList noLista = documento.getElementsByTagName("layout");

            for (int temp = 0; temp < noLista.getLength(); temp++) {
                Node no = noLista.item(temp);
                if (no.getNodeType() == Node.ELEMENT_NODE) {
                    KeyboardLayout layoutTeclado = new KeyboardLayout();
                    Element elemento = (Element) no;
                    layoutTeclado.setTipo(elemento.getAttribute("model"));
                    layoutTeclado.setLine1(elemento.getChildNodes().item(1).getTextContent());
                    layoutTeclado.setLine2(elemento.getChildNodes().item(3).getTextContent());

                    if (elemento.getChildNodes().item(3).getAttributes().getNamedItem("offset") != null) {
                        layoutTeclado.setOffset2(Double.parseDouble(elemento.getChildNodes().item(3).getAttributes().getNamedItem("offset").getNodeValue()));
                    } else {
                        layoutTeclado.setOffset2(0);
                    }

                    layoutTeclado.setLine3(elemento.getChildNodes().item(5).getTextContent());

                    if (elemento.getChildNodes().item(3).getAttributes().getNamedItem("offset") != null) {
                        layoutTeclado.setOffset3(Double.parseDouble(elemento.getChildNodes().item(5).getAttributes().getNamedItem("offset").getNodeValue()));
                    } else {
                        layoutTeclado.setOffset3(0);
                    }
                    listaDeTeclados.add(layoutTeclado);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        listaDeTeclados.add(new KeyboardLayout("Neutro", "", "", "", 0, 0));
        return listaDeTeclados;
    }
}
