package modelo;

import controlador.CalculadorDistancia;
import java.util.HashMap;
import lombok.Data;

/**
 * Nó da BKTree implementado com HashMap.
 */
public @Data
class Node {

    private String Word;
    private HashMap<Integer, Node> Children = new HashMap<Integer, Node>();
    private CalculadorDistancia cd = new CalculadorDistancia();
    private String metodo;
    private KeyboardLayout layout;

    /**
     * Construtor do nó da BKTree que possui três parâmetros: palavra digitada
     * pelo usuário, método (algoritmo para cálculo de distância entre duas
     * palavras) e o modelo de teclado
     *
     * @param word
     * @param metodo
     * @param layout
     */
    public Node(String word, String metodo, KeyboardLayout layout) {
        this.Word = word.toLowerCase();
        this.metodo = metodo;
        this.layout = layout;
    }

    /**
     * Obter filho de um nó
     *
     * @param key
     * @return
     */
    public Node getChild(int key) {
        return Children.get(key);
    }

    /**
     * Adiciona recursivamente as palavras do dicionário na BKTree
     */
    public void addChild(int key, String word) {
        if (this.Children.get(key) == null) {
            this.Children.put(key, new Node(word, metodo, layout));
        } else {
            this.Children.get(key).addChild((int) (cd.calcula(word, this.Children.get(key).getWord(), metodo, layout) * 100), word);
        }
    }
}
