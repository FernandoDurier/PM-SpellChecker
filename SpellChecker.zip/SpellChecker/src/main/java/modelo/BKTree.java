package modelo;

import controlador.CalculadorDistancia;
import lombok.Data;

/**
 * Implementação da BK Tree, concebida em 1973 por Walter Austin Burkhard e
 * Robert M. Keller. Utilizada para fazer verificação ortográfica de uma palavra
 * com base em um dicionário. 
 */
public @Data
class BKTree {

    private Node Root;
    private CalculadorDistancia cd = new CalculadorDistancia();
    private String metodo;
    private KeyboardLayout layout;

    /**
     * Construtor da BK Tree que possui como parâmetros um nó, um método
     * (algoritmo para realizar o cálculo de distância entre duas palavras) e um
     * modelo de teclado.
     *
     * @param Root
     * @param metodo
     * @param layout
     */
    public BKTree(Node Root, String metodo, KeyboardLayout layout) {
        this.Root = Root;
        this.metodo = metodo;
        this.layout = layout;
    }

    /**
     * Adiciona um nó na raiz da BKTree. Utiliza um cálculo necessário para
     * converter double para inteiro.
     */
    public void Add(String word) {
        int dist = (int) ((cd.calcula(word, Root.getWord(), metodo, layout)) * 100);
        Root.addChild(dist, word);
    }

    /**
     * Recebe uma palavra e um nó da BKTree para realizar a verificação
     * ortográfica. O primeiro nó é a raiz da arvore.
     * Se a distância entre a palavra entrada e a palavra do nó for menor ou
     * igual a tolerancia, então retorna essa distância como sugestão. Senão,
     * passa visita o próximo filho com distância relativa para a raiz de
     * distancia entre a palavra entrada e a palavra do nó.
     */
    public String corrigir(String erro, Node referencia, int tolerancia) {

        int distancia = (int) ((cd.calcula(erro, referencia.getWord(), metodo, layout)) * 100);
        Node candidato = referencia.getChild(distancia);

        if (distancia <= tolerancia) {
            return referencia.getWord();
        } else if (candidato != null) {
            return corrigir(erro, candidato, tolerancia);
        } else {
            return "Sem sugestões de correção";
        }
    }
}
